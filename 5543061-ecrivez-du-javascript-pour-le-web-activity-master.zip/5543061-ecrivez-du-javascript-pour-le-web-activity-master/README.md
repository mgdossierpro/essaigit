## Code de projet de cours Open Classrooms ##
Clonez ce repository et ajoutez-y webpack comme expliqué dans l'activité.